
  document.getElementById("welcomeScreen").style.display = "none";
  document.querySelector(".login-container").style.display = "block";
}

function updateUserImage() {
  const type = document.getElementById("userType").value;
  const img = document.getElementById("userImage");

  if (type === "student") {
    img.src = "https://cdn-icons-png.flaticon.com/512/201/201634.png";
  } else if (type === "teacher") {
    img.src = "https://cdn-icons-png.flaticon.com/512/4140/4140048.png";
  } else if (type === "parent") {
    img.src = "https://cdn-icons-png.flaticon.com/512/2922/2922510.png";
  }
}

function login() {
  const userType = document.getElementById("userType").value;
  const gradeLevel = document.getElementById("gradeLevel").value;
  const dashboard = document.getElementById("dashboard");
  const loginContainer = document.querySelector(".login-container");
  const welcomeMessage = document.getElementById("welcomeMessage");
  const gradeTitle = document.getElementById("gradeTitle");
  const content = document.getElementById("content");

  loginContainer.style.display = "none";
  dashboard.classList.remove("hidden");

  gradeTitle.textContent = `📚 ${gradeLevel}`;

  if (userType === "student") {
    welcomeMessage.textContent = "مرحباً بك أيها الطالب الصغير!";
    content.innerHTML = `
      <div class="subject-card"><i class="fas fa-square-root-alt"></i> الرياضيات</div>
      <div class="subject-card"><i class="fas fa-book-open"></i> اللغة العربية</div>
      <div class="subject-card"><i class="fas fa-flask"></i> العلوم</div>
      <div class="subject-card"><i class="fas fa-globe"></i> التربية الاجتماعية</div>
    `;
  } else if (userType === "teacher") {
    welcomeMessage.textContent = "مرحباً بك أيها المعلم!";
    content.innerHTML = `<p>📄 يمكنك إدارة الدروس، إضافة الواجبات، وتصحيح الامتحانات.</p>`;
  } else if (userType === "parent") {
    welcomeMessage.textContent = "مرحباً بك ولي الأمر!";
    content.innerHTML = `<p>👨‍👩‍👧‍👦 يمكنك متابعة مستوى أداء طفلك والاطلاع على تقارير المواد.</p>`;
  }
}

function logout() {
  document.querySelector(".login-container").style.display = "block";
  document.getElementById("dashboard").classList.add("hidden");
}

function showSection(section) {
  const content = document.getElementById("sectionContent");

  if (section === "assignments") {
    content.innerHTML = `
      <h3>📘 واجباتي</h3>
      <ul>
        <li>📎 الرياضيات: حل مسائل الجمع والطرح</li>
        <li>📎 العلوم: مشاهدة فيديو عن الكائنات الحية</li>
        <li>📎 اللغة العربية: كتابة قصة قصيرة</li>
      </ul>
      <h4>🎨 أنشطة</h4>
      <p>صمم مجسم لحيوانك المفضل باستخدام الورق.</p>
    `;
  } else if (section === "games") {
    content.innerHTML = `
      <h3>🎮 ألعاب تعليمية</h3>
      <ul>
        <li>🔢 لعبة الجمع والطرح</li>
        <li>🧠 لعبة ترتيب الحروف</li>
        <li>🌍 لعبة الجغرافيا المصورة</li>
      </ul>
    `;
  } else if (section === "messages") {
    content.innerHTML = `
      <h3>✉️ صندوق الرسائل</h3>
      <p><strong>من المعلم:</strong> أحسنت في حل الواجب يا بطل!</p>
      <p><strong>إلى ولي الأمر:</strong> نرجو متابعة الطالب في الواجبات القادمة.</p>
      <textarea placeholder="أكتب رسالة للمعلم أو ولي الأمر..." style="width: 100%; height: 80px; border-radius: 10px;"></textarea>
      <br><button style="margin-top: 10px;">📨 إرسال</button>
    `;
  } else if (section === "support") {
    content.innerHTML = `
      <h3>🛠 الدعم الفني</h3>
      <p>لأي مشاكل تقنية، يرجى التواصل مع فريق الدعم عبر:</p>
      <ul>
        <li>📧 البريد الإلكتروني: support@schoolapp.com</li>
        <li>📞 الهاتف: 1234-567-890</li>
        <li>💬 أو من خلال هذه الرسالة:</li>
      </ul>
      <textarea placeholder="صف مشكلتك هنا..." style="width: 100%; height: 80px; border-radius: 10px;"></textarea>
      <br><button style="margin-top: 10px;">🚑 إرسال للدعم</button>
    `;
  }
}
